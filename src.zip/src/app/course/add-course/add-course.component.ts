import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CourseServiceService } from 'src/app/services/course-service.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  course:Course=new Course();
  submitted=false;

  constructor(private courseservice:CourseServiceService,
    private router:Router) { }

  ngOnInit(){
  }

  newCourse():void{
    this.submitted=true;
    this.course=new Course();
  }

  save(){
    this.courseservice.createCourse(this.course).subscribe(data =>{
      console.log(data)
      this.course=new Course();
      this.gotoList();
    },
    error => console.log(error));
  }

  onSubmit(){
    this.submitted=true;
    this.save();
  }

  gotoList(){
    this.router.navigate(['/course']);
  }

}
