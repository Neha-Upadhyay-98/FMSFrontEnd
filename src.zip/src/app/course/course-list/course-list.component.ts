import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Course } from 'src/app/models/course';
import { CourseServiceService } from 'src/app/services/course-service.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses!:Observable<Course[]>;

  constructor(private courseservice:CourseServiceService,
    private router:Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.courses=this.courseservice.getCourseList();
  }

  deleteCourse(id:string){
    this.courseservice.deleteCourse(id).subscribe(data =>{
      console.log(data);
      this.reloadData();
    },
    error => console.log(error));
  }

  updateCourse(id:string){
    this.router.navigate(['update',id]);
  }

}
