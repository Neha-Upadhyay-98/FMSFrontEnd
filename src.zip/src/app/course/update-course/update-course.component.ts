import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CourseServiceService } from 'src/app/services/course-service.service';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {

  id:string="";
  course!:Course;

  constructor(private route:ActivatedRoute,private router:Router,
    private courseservice:CourseServiceService) { }

  ngOnInit(): void {
    this.course=new Course();
    this.id=this.route.snapshot.params['id'];
    this.courseservice.getCourse(this.id).subscribe(data=>{
      console.log(data)
      this.course=data;
    },error => console.log(error));
  }

  updateCourse(){
    this.courseservice.updateCourse(this.id,this.course).subscribe(data =>{
      this.course=new Course();
      this.gotoList();

    },error=> console.log(error))
  }

  gotoList(){
    this.router.navigate(['/course']);
  }

  onSubmit(){
    this.updateCourse();
  }

}
