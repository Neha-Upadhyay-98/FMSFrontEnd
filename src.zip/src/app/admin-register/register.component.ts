import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from '../models/admin';
import { Participant } from '../models/participant';
import { Trainer } from '../models/trainer';
import { AdminService } from '../services/admin.service';
import { ParticipantService } from '../services/participant.service';
import { TrainerService } from '../services/trainer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  roles=['Admin','Trainer','Participant'];

  registerForm!:FormGroup;

  newAdmin:Admin=new Admin();
  newTrainer:Trainer=new Trainer();
  newParticipant:Participant=new Participant();

  id!:FormControl;
  name!:FormControl;
  username!:FormControl;
  password!:FormControl;
  role!:FormControl;
  skill!:FormControl;
 // feedbackList!:FormControl;

  formSubmitted=false;

  constructor(private adminService:AdminService, private trainerService:TrainerService, private participantService:ParticipantService, private router:Router) { }

  ngOnInit(): void {
    this.id=new FormControl('',Validators.required);
    this.name=new FormControl('',Validators.required);
    this.username=new FormControl('',Validators.required);
    this.password=new FormControl('',[Validators.required,Validators.minLength(8)]);
    this.role=new FormControl('Admin',Validators.required);
    this.skill=new FormControl('',Validators.required);
   // this.feedbackList=new FormControl('');

    this.registerForm=new FormGroup({
      'id':this.id,
      'name':this.name,
      'username':this.username,
      'password':this.password,
      'role':this.role,
      'skill':this.skill,
      //'feedbackList':this.feedbackList
    });
  }

  onSubmit(){

    console.log(this.role.value);

    console.log(this.registerForm.value);
    console.log(this.role.value=='Admin');

    if(this.role.value=='Admin'){
      console.log("entered");
      this.newAdmin.adminName=this.registerForm.controls['name'].value;
      this.newAdmin.adminUserName=this.registerForm.controls['username'].value;
      this.newAdmin.adminPassword=this.registerForm.controls['password'].value;
      this.newAdmin.role=this.registerForm.controls['role'].value;
      this.addAdmin(this.newAdmin);
    }
    else if(this.role.value=='Trainer'){
      this.newTrainer.trainerId=this.registerForm.controls['id'].value;
      this.newTrainer.trainerName=this.registerForm.controls['name'].value;
      this.newTrainer.trainerUserName=this.registerForm.controls['username'].value;
      this.newTrainer.trainerPassword=this.registerForm.controls['password'].value;
      this.newTrainer.skill=this.registerForm.controls['skill'].value;
     // this.newTrainer.feedbackList=this.registerForm.controls['feedbackList'].value;
      this.addTrainer(this.newTrainer);
    }
    else{
      this.newParticipant.participantName=this.registerForm.controls['name'].value;
      this.newParticipant.participantUserName=this.registerForm.controls['username'].value;
      this.newParticipant.participantPassword=this.registerForm.controls['password'].value;
      this.newParticipant.role=this.registerForm.controls['role'].value;
      this.addParticipant(this.newParticipant);
    }
  }

  addAdmin(admin:Admin){
    this.adminService.addAdmin(admin).subscribe(data =>{
      console.log(data)
    },
    error => console.log(error));

    this.formSubmitted=true;
  }

  addTrainer(trainer:Trainer){
    this.trainerService.addTrainer(trainer).subscribe(data =>{
      console.log(data)
    },
    error => console.log(error));

    this.formSubmitted=true;
  }

  addParticipant(participant:Participant){
    this.participantService.addParticipant(participant).subscribe(data =>{
      console.log(data)
    },
    error => console.log(error));

    this.formSubmitted=true;
  }
}
