import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {

  private baseUrl= 'http://localhost:8121/fms/course';

  constructor(private http:HttpClient) { }

  getCourseList(): Observable<any>{
    return this.http.get(`${this.baseUrl}`);
  }

  createCourse(course: object): Observable<object>{
    return this.http.post(`${this.baseUrl}`,course);
  }

  deleteCourse(id:string): Observable<Object>{
    return this.http.delete(`${this.baseUrl}/${id}`,{ responseType:'text'});
  }

  getCourse(id:string): Observable<any>{
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  updateCourse(id:string, value:any): Observable<Object>{
    return this.http.put(`${this.baseUrl}/${id}`,value);
  }
}
