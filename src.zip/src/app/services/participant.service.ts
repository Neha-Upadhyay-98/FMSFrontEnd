import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Participant } from '../models/participant';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {
  
  private baseUrl="http://localhost:8121/fms/participant";
  constructor(private http:HttpClient) { }

  addParticipant(participant:Participant):Observable<Object>{
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(participant);
    console.log(body);
    return this.http.post(`${this.baseUrl}/add`,participant);
  }

  getAllParticipants():Observable<any>{
    return this.http.get(`${this.baseUrl}/viewall`);
  }

  getParticipant(id:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/viewbyid/${id}`);
  }

  updateParticipant(id:string,value:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/update/${id}`,value);
  }

  deleteParticipant(id:string){
    return this.http.delete(`${this.baseUrl}/delete/${id}`);
  }
}
