import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainer } from '../models/trainer';

@Injectable({
  providedIn: 'root'
})
export class TrainerService {
  
  private baseUrl="http://localhost:8121/fms/trainer";
  constructor(private http:HttpClient) { }

  addTrainer(trainer:Trainer):Observable<Object>{
    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(trainer);
    console.log(body);
    return this.http.post(`${this.baseUrl}/add`,trainer);
  }

  getAllTrainers():Observable<any>{
    return this.http.get(`${this.baseUrl}/viewall`);
  }

  getTrainerById(id:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/viewbyid/${id}`);
  }

  getTrainerBySkill(skill:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/viewbyskill/${skill}`);
  }

  updateTrainer(id:string, value:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/update/${id}`,value);
  }

  deleteTrainer(id:string){
    return this.http.delete(`${this.baseUrl}/delete/${id}`);
  }
}
