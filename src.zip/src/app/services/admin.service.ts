import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { param } from 'jquery';
import { Observable } from 'rxjs';
import { Admin } from '../models/admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private baseUrl="http://localhost:8121/fms/admin";

  private add="add";
  private viewAll="viewAll";

  newAdmin:Admin=new Admin();
  constructor(private http:HttpClient) { }


  addAdmin(admin:Admin):Observable<Object>{

    const headers = { 'content-type': 'application/json'}
    const body=JSON.stringify(admin);
    console.log(body);
    return this.http.post(`${this.baseUrl}/add`,body,{'headers':headers});
  }

  getAllAdmins():Observable<any>{
    return this.http.get(`${this.baseUrl}/viewall`);
  }

  getAdmin(id:string):Observable<any>{
    return this.http.get(`${this.baseUrl}/viewbyid/${id}`);
  }

  updateAdmin(id:string,value:any):Observable<any>{
    return this.http.put(`${this.baseUrl}/update/${id}`,value);
  }

  deleteAdmin(id:string){
    return this.http.delete(`${this.baseUrl}/delete/${id}`);
  }
}
