import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCourseComponent } from './course/add-course/add-course.component';
import { CourseListComponent } from './course/course-list/course-list.component';
import { CourseComponent } from './course/course.component';
import { UpdateCourseComponent } from './course/update-course/update-course.component';
import { LoginComponent } from './login/login.component';
import { ParticipantPortalComponent } from './participant-portal/participant-portal.component';
import { RegisterComponent } from './admin-register/register.component';

const routes: Routes = [
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'participant/:id',
    component:ParticipantPortalComponent
  },
  {
    path:'course-page',
    component:CourseComponent
  },
  {
    path:'course-list',
    component:CourseListComponent
  },
  {
    path:'add-course',
    component:AddCourseComponent
  },
  {
    path:'update/:id',
    component:UpdateCourseComponent
  }

]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
