import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantPortalComponent } from './participant-portal.component';

describe('ParticipantPortalComponent', () => {
  let component: ParticipantPortalComponent;
  let fixture: ComponentFixture<ParticipantPortalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParticipantPortalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantPortalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
