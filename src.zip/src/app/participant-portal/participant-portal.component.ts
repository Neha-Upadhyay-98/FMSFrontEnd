import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Participant } from '../models/participant';
import { ParticipantService } from '../services/participant.service';

@Component({
  selector: 'app-participant-portal',
  templateUrl: './participant-portal.component.html',
  styleUrls: ['./participant-portal.component.css']
})
export class ParticipantPortalComponent implements OnInit {

  partId!:string;
  participant!:Participant;

  constructor(private route:ActivatedRoute, private participantService:ParticipantService, private router:Router) { }

  ngOnInit(): void {

    this.route.paramMap.subscribe(params =>{
      this.partId=this.route.snapshot.params['id'];
    });

    this.participantService.getParticipant(this.partId).subscribe(data =>{
      this.participant=data;
    }, error => console.log(error));
  }

  goDetails(){
    this.router.navigate(['participant',this.partId,'details']);
  }

}
