import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Admin } from '../models/admin';
import { Participant } from '../models/participant';
import { Trainer } from '../models/trainer';
import { AdminService } from '../services/admin.service';
import { ParticipantService } from '../services/participant.service';
import { TrainerService } from '../services/trainer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  roles=['admin','trainer','participant'];
  admins:Admin[]=[];
  trainers:Trainer[]=[];
  participants:Participant[]=[];
  currentAdmin!:Admin;
  currentTrainer!:Trainer;
  currentParticipant!:Participant;
  loginForm!:FormGroup;

  username!:FormControl;
  password!:FormControl;
  role!:FormControl;

  showErrorMessage=false;

  constructor(private adminService:AdminService,private trainerService:TrainerService, private participantService:ParticipantService, private router:Router) { }

  ngOnInit(): void {

    this.username=new FormControl('',Validators.required);
    this.password=new FormControl('',Validators.required);
    this.role=new FormControl('admin');
    this.loginForm=new FormGroup({
      'username':this.username,
      'password':this.password,
      'role':this.role,
    });  
  }

  onSubmit(){
    if(this.role.value=="admin"){
      this.adminLogin();
    }
    else if(this.role.value=="trainer"){
      this.trainerLogin();
    }
    else{
      this.participantLogin();
    }
  }

  adminLogin(){
    this.adminService.getAllAdmins().subscribe(data =>{
      this.admins=data;
      this.admins.forEach(admin =>{
        if(admin.adminUserName==this.loginForm.get('username')?.value){
          if(admin.adminPassword==this.loginForm.get('password')?.value){
            this.currentAdmin=admin;
          }
        }
      });

      if(this.currentAdmin==null){
        this.showErrorMessage=true;
      }
      else{
        this.router.navigate(['admin',this.currentAdmin.adminUserName]);
      }
    });

    this.showErrorMessage=false;
  }

  trainerLogin(){
    this.trainerService.getAllTrainers().subscribe(data =>{
      this.trainers=data;
      this.trainers.forEach(trainer =>{
        if(trainer.trainerUserName==this.loginForm.get('username')?.value){
          if(trainer.trainerPassword==this.loginForm.get('password')?.value){
            this.currentTrainer=trainer;
          }
        }
      });

      if(this.currentTrainer==null){
        this.showErrorMessage=true;
      }
      else{
        this.router.navigate(['trainer',this.currentTrainer.trainerId]);
      }
    });

    this.showErrorMessage=false;
  }

  participantLogin(){
    this.participantService.getAllParticipants().subscribe(data =>{
      this.participants=data;
      this.participants.forEach(participant =>{
        if(participant.participantUserName==this.loginForm.get('username')?.value){
          if(participant.participantPassword==this.loginForm.get('password')?.value){
            this.currentParticipant=participant;
          }
        }
      });

      if(this.currentParticipant==null){
        this.showErrorMessage=true;
      }
      else{
        this.router.navigate(['participant/',this.currentParticipant.participantUserName]);
      }
    });

    this.showErrorMessage=false;
  }

}
