import { Admin } from "./admin";

export class MockData{
    public static Admins:Admin[]=[
        {
            'adminUserName':'Jim Halpert',
            'adminPassword': 'Halpert@123',
            'role':'Admin'
        },
        {
            'adminUserName':'Michael Scott',
            'adminPassword': 'Michael@124',
            'role':'Admin'
        }
    ];
}