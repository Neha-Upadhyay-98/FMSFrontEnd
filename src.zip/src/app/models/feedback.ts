export class Feedback{
    feedbackId:number = 0;
    prgId:string = "";
    trnId:string = "";
    feedbackCriteria1:string = "";
    feedbackCriteria2:string = "";
    feedbackCriteria3:string = "";
    feedbackCriteria4:string = "";
    feedbackCriteria5:string = "";
    comments:string = "";
    suggestions:string = "";
}