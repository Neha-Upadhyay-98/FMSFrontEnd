export class Course{
    courseId:string = "";
    courseName:string = "";
    courseDescription:string = "";
    noOfDays:string = "";
    prgId:string = "";
}