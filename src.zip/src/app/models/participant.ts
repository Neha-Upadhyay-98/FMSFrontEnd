export class Participant{
    participantName:string = "";
    participantUserName:string = "";
    participantPassword:string = "";
    role:string = "Participant";
}