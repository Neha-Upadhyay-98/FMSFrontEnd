export class Trainer{
    trainerId:string = "";
    trainerName:string = "";
    trainerUserName:string = "";
    trainerPassword:string = "";
    role:string = "Trainer";
    skill:string = "";
    feedbackList:Array<string> = [];
}