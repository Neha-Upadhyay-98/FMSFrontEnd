export class Admin{
    adminName:string="";
    adminUserName:string = "";
    adminPassword:string = "";
    role:string = "Admin";
}