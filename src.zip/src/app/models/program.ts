export class Program{
    programId:string = "";
    programName:string = "";
    startDate:string = "";
    endDate:string = "";
    tid:string = "";
    courseList:Array<string> = [];
    feedbackList:Array<string> = [];
}